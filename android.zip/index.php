<!DOCTYPE HTML>
<?php session_start(); ?>
<html>

<head>
	<title>tiankonguse~tool</title>
</head>
<body > 

<div>分类</div>

<div>
	<a href="./update_class.php" target="_bank">update_class</a>
</div>
<div>
	<a href="./get_class.php" target="_bank">get_class</a>
</div>


<div>排行榜</div>

<div>
	<a href="./update_rank.php" target="_bank">update_rank</a>
</div>
<div>
	<a href="./get_rank.php" target="_bank">get_rank</a>
</div>

<div>
	<a href="./update_cid.php?cid=403" target="_bank">update_cid</a>
</div>


<div>
	<a href="./get_cid.php?cid=403" target="_bank">get_cid</a>
</div>

<div>
	<a href="./update_game.php?id=3063135" target="_bank">update_game</a>
</div>

<div>
	<a href="./get_game.php?id=3063135" target="_bank">get_game</a>
</div>



</body>
</html>

 
 
 